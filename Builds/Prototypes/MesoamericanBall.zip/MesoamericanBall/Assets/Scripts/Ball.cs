﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ball : MonoBehaviour 
{
    public LayerMask mask;
    CircleCollider2D col2d;
    Vector2 velocity;
    float skinWidth = 0.015f;
    public float gravity = 0f;

    public Vector2 initialVelocity;

    void Start()
	{
        velocity = initialVelocity;
        col2d = GetComponent<CircleCollider2D>();
	}

    void Update()
    {
        velocity.y -= gravity * Time.deltaTime;
        float frameSpeed = Time.deltaTime * velocity.magnitude;
        Vector2 dir = velocity.normalized;
        RaycastHit2D hit = Physics2D.CircleCast((Vector2)transform.position, col2d.radius + skinWidth, dir, frameSpeed, mask);
        if(!hit || hit.transform.GetComponent<Collider2D>().isTrigger)
        {
            transform.Translate(frameSpeed * dir);
        }
        else
        {
            transform.Translate(hit.centroid - (Vector2)transform.position);
            Vector2 u = hit.normal * Vector2.Dot(dir, hit.normal);
            Vector2 w = dir - u;
            velocity = (w - u) * frameSpeed / Time.deltaTime;

            if (hit.transform.gameObject.layer == LayerMask.NameToLayer("Player"))
            {
                velocity = velocity.normalized * velocity.magnitude;
            }
            transform.Translate(velocity.normalized * skinWidth);
        }
    }
    

	void OnCollisionEnter2D(Collision2D col2d)
	{
		Player p = col2d.transform.GetComponent<Player> ();
		if (p) 
		{
			velocity += p.getVelocity;
		}
		transform.Translate (velocity * Time.deltaTime);
	}
}
