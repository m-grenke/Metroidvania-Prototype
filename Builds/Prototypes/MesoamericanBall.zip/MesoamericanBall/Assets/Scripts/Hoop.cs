﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Hoop : MonoBehaviour
{
    SpriteRenderer ball;
    SpriteRenderer hoop;

    void Start()
    {
        hoop = GetComponent<SpriteRenderer>();
    }

    void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.tag == "Ball")
        {
            if(ball == null)
            {
                ball = col.GetComponent<SpriteRenderer>();
            }
            if(ball.sortingOrder > hoop.sortingOrder) // if ball is in front
            {
                ball.sortingOrder -= 2; //move behind
            }
            else
            {
                ball.sortingOrder += 2; //move in front
            }
        }
    }
	
}
